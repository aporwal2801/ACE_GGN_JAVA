package delay.queue;

import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

public class DelayObject implements Delayed {

	private String delayElementId;
	private long expiryTime;

	DelayObject(String delayElementId, long expiryTime) {
		this.delayElementId = delayElementId;
		this.expiryTime = System.currentTimeMillis() + expiryTime;
	}

	@Override
	public int compareTo(Delayed o) {
		if (this.expiryTime > ((DelayObject) o).expiryTime) {
			return 1;
		} else if (this.expiryTime < ((DelayObject) o).expiryTime) {
			return -1;
		}
		return 0;
	}

	@Override
	public long getDelay(TimeUnit unit) {
		long delayTime = this.expiryTime - System.currentTimeMillis();
		// System.out.println("delay time "+delayTime);
		return unit.convert(delayTime, TimeUnit.MILLISECONDS);
	}

	@Override
	public String toString() {
		return "DelayObject [delayElementId=" + delayElementId
				+ ", expiryTime=" + expiryTime + "]";
	}

}
