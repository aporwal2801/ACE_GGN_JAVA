package delay.queue;

import java.util.Random;
import java.util.concurrent.DelayQueue;

public class DelayProducer implements Runnable {

	DelayQueue<DelayObject> queue;
	Random random = new Random();
	int elemnetId = 0;
	long delay = 0;
	DelayObject delayObject = null;
	String element_id = null;

	public DelayProducer(DelayQueue<DelayObject> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			elemnetId = random.nextInt(10);
			element_id = elemnetId + "";
			delay = 5000 + random.nextInt(100);
			// delay = 10000;
			delayObject = new DelayObject(element_id, delay);
			queue.put(delayObject);
		}
	}
}
