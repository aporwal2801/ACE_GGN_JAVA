package delay.queue;

import java.util.concurrent.DelayQueue;

public class DelayConsumer implements Runnable {

	DelayQueue<DelayObject> queue;

	public DelayConsumer(DelayQueue<DelayObject> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		while (true) {
			try {
				DelayObject take = queue.take();
				System.out.println("ThreadName: "
						+ Thread.currentThread().getName() + " TAKE : " + take);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
