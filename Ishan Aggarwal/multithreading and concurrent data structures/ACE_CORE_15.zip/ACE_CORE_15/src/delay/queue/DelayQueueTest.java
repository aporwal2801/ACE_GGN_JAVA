package delay.queue;

import java.util.concurrent.DelayQueue;

public class DelayQueueTest {

	public static void main(String[] args) {

		System.out.println("Main Thread Started");
		DelayQueue<DelayObject> queue = new DelayQueue<>();
		DelayProducer dp = new DelayProducer(queue);
		DelayConsumer dc1 = new DelayConsumer(queue);
		DelayConsumer dc2 = new DelayConsumer(queue);

		Thread dpThread = new Thread(dp);
		dpThread.start();

		Thread dcThread1 = new Thread(dc1);
		Thread dcThread2 = new Thread(dc2);

		dcThread1.start();
		dcThread2.start();
	}
}
