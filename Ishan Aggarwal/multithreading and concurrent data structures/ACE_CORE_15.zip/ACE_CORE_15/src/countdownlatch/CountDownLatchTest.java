package countdownlatch;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchTest {

	private static int counter = 1;
	private static CountDownLatch countDownLatch = new CountDownLatch(3);

	public static class CounterThread implements Runnable {

		@Override
		public void run() {
			System.out.println(Thread.currentThread().getName() + " - "
					+ counter++);
			countDownLatch.countDown();
		}
	}

	public static void main(String[] args) throws InterruptedException {

		System.out.println("Main Thread started");
		CounterThread thread1 = new CounterThread();
		CounterThread thread2 = new CounterThread();
		CounterThread thread3 = new CounterThread();
		
		Thread threadC1 = new Thread(thread1);
		Thread threadC2 = new Thread(thread2);
		Thread threadC3 = new Thread(thread3);
		
		threadC1.start();
		threadC2.start();
		threadC3.start();
		
//		threadC1.start();

		countDownLatch.await();
		System.out.println("Main Thread ended");

	}
}
