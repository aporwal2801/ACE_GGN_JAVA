package exchanger;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.Exchanger;

public class ExchangerExample {

	Exchanger<List<Integer>> exchanger = new Exchanger<>();

	private class Producer implements Runnable {
		private List<Integer> queue = new ArrayList<>();
		List<Integer> oddList;

		public Producer(List<Integer> list1) {
			this.oddList = list1;
		}

		@SuppressWarnings("unchecked")
		@Override
		public void run() {
			try {
				// create tasks & fill the queue
				// exchange the full queue for a empty queue with Consumer

				for (Integer element : oddList) {
					if (element % 2 == 0) {
						queue.add(element);
					}
				}
				List<Integer> exchange1 = exchanger.exchange(queue);
				System.out.println(Thread.currentThread().getName()
						+ " has exchanged " + queue + " -- for : " + exchange1);

				oddList.removeAll(queue);
				oddList.addAll(exchange1);
				
				System.out.println("Final oddList : " + oddList);

			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private class Consumer implements Runnable {

		private List<Integer> evenQueue = new ArrayList<>();
		List<Integer> evenList;

		public Consumer(List<Integer> list2) {
			this.evenList = list2;
		}

		@Override
		public void run() {
			try {
				// create tasks & fill the queue
				// exchange the full queue for a empty queue with Consumer
				for (Integer element : evenList) {
					if (element % 2 != 0) {
						evenQueue.add(element);
					}
				}
				List<Integer> exchange2 = exchanger.exchange(evenQueue);
				System.out.println(Thread.currentThread().getName()
						+ " has exchanged " + evenQueue + " -- for : " + exchange2);
				
				evenList.removeAll(evenQueue);
				evenList.addAll(exchange2);
				
				System.out.println("Final evenList : " + evenList);

				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void start() {

		List<Integer> list1 = new ArrayList<>(10);
		List<Integer> list2 = new ArrayList<>(10);
		Random random = new Random();

		for (int i = 0; i < 10; i++) {
			list1.add(random.nextInt(100));
		}

		for (int i = 0; i < 10; i++) {
			list2.add(random.nextInt(100));
		}

		System.out.println("list1 : " + list1);
		System.out.println("list2 : " + list2);

		new Thread(new Producer(list1), "Producer").start();
		new Thread(new Consumer(list2), "Consumer").start();
		
	}

	public static void main(String[] args) {
		new ExchangerExample().start();
	}

}