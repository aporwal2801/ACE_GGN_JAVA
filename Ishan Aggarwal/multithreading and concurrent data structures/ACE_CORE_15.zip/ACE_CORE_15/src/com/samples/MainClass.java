package com.samples;

import java.util.ArrayList;
import java.util.List;

public class MainClass {

	private static class RunnableTask implements Runnable {
		String msg = null;

		public RunnableTask(String msg) {
			this.msg = msg;
		}

		@Override
		public void run() {
			try {
				Thread.sleep(1000);
				System.out.println(msg + " done.");
			} catch (InterruptedException e) {
				System.out.println(e);
			}
		}
	}

	public static void main(String[] args) {
		PhaserDemo phaserDemo = new PhaserDemo();
		RunnableTask task1 = new RunnableTask("Task one");
		RunnableTask task2 = new RunnableTask("Task two");
		List<Runnable> tasks = new ArrayList<Runnable>();
		tasks.add(task1);
		tasks.add(task2);
		phaserDemo.doTasks(tasks);
		phaserDemo.initializeTasks(tasks, 2);
	}
}
