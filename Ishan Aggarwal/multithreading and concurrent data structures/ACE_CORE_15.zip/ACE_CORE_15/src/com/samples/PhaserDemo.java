package com.samples;

import java.util.List;
import java.util.concurrent.Phaser;

public class PhaserDemo {
	public void doTasks(List<Runnable> tasks) {
		final Phaser phaser = new Phaser();
		for (final Runnable task : tasks) {
			phaser.register();
			new Thread() {
				public void run() {
					phaser.arriveAndAwaitAdvance();
					task.run();
				}
			}.start();
		}
		phaser.arriveAndDeregister();
	}

	public void initializeTasks(List<Runnable> tasks, final int iterations) {
		final Phaser phaser = new Phaser() {
			protected boolean onAdvance(int phase, int registeredParties) {
				return phase >= iterations || registeredParties == 0;
			}
		};
		phaser.register();
		for (final Runnable task : tasks) {
			phaser.register();
			new Thread() {
				public void run() {
					do {
						task.run();
						phaser.arriveAndAwaitAdvance();
					} while (!phaser.isTerminated());
				}
			}.start();
		}
		phaser.arriveAndDeregister();
	}
}
