package semaphore;

import java.util.concurrent.Semaphore;

public class TestSemaphore {

	Semaphore binary = new Semaphore(1);
	private int counter = 1;

	public static void main(String args[]) {
		final TestSemaphore test = new TestSemaphore();
		new Thread() {
			@Override
			public void run() {
				while (true) {
					test.mutualExclusion();
				}
			}
		}.start();

		new Thread() {
			@Override
			public void run() {
				while (true) {
					test.mutualExclusion();
				}
			}
		}.start();

	}

	private void mutualExclusion() {
		try {
			Thread.sleep(1000);
			binary.acquire();
			if (counter % 2 == 1
					&& !Thread.currentThread().getName()
							.equals("Thread-" + (counter % 2))) {

				System.out.println(Thread.currentThread().getName() + " - "
						+ counter);
				counter++;
			} else if (counter % 2 == 0
					&& !Thread.currentThread().getName()
							.equals("Thread-" + (counter % 2))) {
				System.out.println(Thread.currentThread().getName() + " - "
						+ counter);
				counter++;
			}
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		} finally {
			binary.release();
		}
	}
}
