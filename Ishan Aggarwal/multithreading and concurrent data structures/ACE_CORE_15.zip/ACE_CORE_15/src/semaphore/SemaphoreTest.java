package semaphore;

import java.util.concurrent.Semaphore;

public class SemaphoreTest {

	public static class Producer implements Runnable {

		private Semaphore sem;
		private volatile Integer counterOne;

		public Producer(Semaphore semaphore, Integer counter) {
			this.sem = semaphore;
			this.counterOne = counter;
		}

		@Override
		public void run() {
			while (true) {
				try {
					Thread.sleep(1000);
					sem.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out
						.println("Thread: " + Thread.currentThread().getName()
								+ " - " + counterOne);
				counterOne = counterOne + 2;
				sem.release();
			}
		}

	}

	public static class Consumer implements Runnable {

		Semaphore sem;
		Integer counterTwo;

		public Consumer(Semaphore semaphore, Integer counter) {
			this.sem = semaphore;
			this.counterTwo = counter;
		}

		@Override
		public void run() {
			while (true) {
				try {
					Thread.sleep(1000);
					sem.acquire();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				System.out
						.println("Thread: " + Thread.currentThread().getName()
								+ " - " + counterTwo);
				counterTwo += 2;
				sem.release();
			}

		}

	}

	public static void main(String[] args) {
		SemaphoreTest semaphoreTest = new SemaphoreTest();
		Semaphore semaphore = new Semaphore(1);
		Integer counterOne = new Integer(1);
		Integer counterTwo = new Integer(2);
		Producer producer = new Producer(semaphore, counterOne);
		Consumer consumer = new Consumer(semaphore, counterTwo);
		Thread producerThread = new Thread(producer, "Producer-Thread");
		Thread consumerThread = new Thread(consumer, "Consumer-Thread");
		producerThread.start();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		consumerThread.start();

	}

}
