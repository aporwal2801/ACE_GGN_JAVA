package custom.threadpool.executor;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class CustomThreadPoolExecutor {

	private static class MyTask implements Runnable {
		@Override
		public void run() {
			while (true) {
				System.out.println("I am executing task");
				try {
					Thread.sleep(10000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public static void main(String s[]) {

		System.out.println("Main thread started!!!");

		BlockingQueue<Runnable> myBlockingQueue = new LinkedBlockingQueue<>(1);
		RejectedExecutionHandler handler = new RejectedExecutionHandler() {

			@Override
			public void rejectedExecution(Runnable r,
					ThreadPoolExecutor executor) {
				throw new RejectedExecutionException(
						"No more task can be submitted");
			}
		};

		ThreadPoolExecutor threadPool = new ThreadPoolExecutor(1, 2, 1000,
				TimeUnit.MILLISECONDS, myBlockingQueue, handler);

		MyTask task1 = new MyTask();
		MyTask task2 = new MyTask();
		MyTask task3 = new MyTask();

		threadPool.submit(task1);
		threadPool.submit(task2);
		threadPool.submit(task3);
		threadPool.submit(task3);
		// threadPool.submit(task3);

		System.out.println("Main thread ended!!!");
	}
}
