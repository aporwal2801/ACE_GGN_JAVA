package com.sapient.collections;

import java.util.Collection;
import java.util.HashMap;

public class TestClass<K,V> {

	Collection c = (Collection) /*(Collection)*/ new HashMap<K,V>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		

	}

}
