package com.sapient.testclasses;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.sapient.cache.CacheObject;
import com.sapient.cache.ExpirationBasedCacheImpl;

public class TestCacheExpirationPolicy {

	private static ExpirationBasedCacheImpl<CacheObject, Object> expiryCache = null;
	private static CacheObject cacheObject = null;
	private static List<CacheObject> cacheList = new ArrayList<>(20);
	private static int timeToLive = 3600;

	@BeforeClass
	public static void setUpFixture() {
		expiryCache = new ExpirationBasedCacheImpl<>(10, timeToLive);
		for (int i = 0; i < 9; i++) {
			Long time = System.currentTimeMillis();
			cacheObject = new CacheObject(i, time);
			cacheList.add(cacheObject);
			expiryCache.put(cacheObject);
		}
	}

	@AfterClass
	public static void tearDownFixture() {
		for (int i = 0; i < 5; i++) {
			expiryCache.invalidateCache();
		}
	}

	@After
	public void afterMethodCall() {

	}

	@Before
	public void beforeMethodCall() {

	}

	@Test
	public void removeElementTest() {
		CacheObject cacheObject = new CacheObject(20,
				System.currentTimeMillis());
		Object remove = expiryCache.remove(cacheObject);
		assertEquals("Removed Object with key " + cacheObject, remove, null);
	}

	@Test
	public void getTest() {
		CacheObject cacheObject = new CacheObject(20,
				System.currentTimeMillis());
		Long currentTime = System.currentTimeMillis();
		Object value = expiryCache.get(cacheObject);
		Long accessTime = cacheObject.getAccessTime();
		int difference = 0;
		int tempDifference = Math.abs(currentTime - accessTime) > 1000 ? 1 : 0;

		assertEquals("Get Element Difference is Zero", difference,
				tempDifference);
	}

	@Test
	public void putTest() {
		int mapSize = expiryCache.getCacheMap().size();
		expiryCache.put(new CacheObject(20, System.currentTimeMillis()));
		mapSize++;
		assertEquals("Equals", mapSize, expiryCache.getCacheMap().size());
	}

	@Test
	public void cacheEvictionTest() {
		Long time = System.currentTimeMillis();
		int count = 0;
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Map<CacheObject, Object> cacheMap = expiryCache.getCacheMap();
		Set<CacheObject> keySet = cacheMap.keySet();
		for (CacheObject key : keySet) {
			Long accessTime = key.getAccessTime();
			if (Math.abs(accessTime - time) * 1000 > timeToLive) {
				count++;
			}
		}
		System.out.println("SIZE: " + expiryCache.getCacheMap().size());
		int numberOfElementsRemoved = expiryCache.invalidateCache();
		System.out.println("numberOfElementsRemoved : "
				+ numberOfElementsRemoved);
		System.out.println("Count : " + count);
		System.out.println("SIZE: " + expiryCache.getCacheMap().size());
		assertEquals(count, numberOfElementsRemoved);

	}
}
