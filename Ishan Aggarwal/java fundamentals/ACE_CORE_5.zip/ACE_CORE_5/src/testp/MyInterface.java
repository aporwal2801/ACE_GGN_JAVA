package testp;

public interface MyInterface {

	void myMethod();
}
