package testp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Employee implements Serializable {

	static int a = 10;
	transient int b = 5;
	final transient int c;
	final transient int d = 15;
	static transient int e = 25;
	int f = 30;

	Employee() {
		c = 100;
		f = 500;
	}

}

public class Test {

	public static void main(String[] args) throws IOException,
			ClassNotFoundException {
		// TODO Auto-generated method stub

		Employee e = new Employee();

		System.out.println("static int a = " + e.a);
		System.out.println("transient int b = " + e.b);
		System.out.println("final transient int c = " + e.c);
		System.out.println("final transient int d = " + e.d);
		System.out.println("static transient int e = " + e.e);
		System.out.println("int f = " + e.f);

		
		
		System.out.println("-------------------------------------------------");

		FileOutputStream fos = new FileOutputStream(new File("my.ser"));
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeObject(e);

		e.a = 20;
		
		FileInputStream fis = new FileInputStream(new File("my.ser"));
		ObjectInputStream ois = new ObjectInputStream(fis);
		Employee e1 = (Employee) ois.readObject();

		System.out.println("static int a = " + e1.a);
		System.out.println("transient int b = " + e1.b);
		System.out.println("final transient int c = " + e1.c);
		System.out.println("final transient int d = " + e1.d);
		System.out.println("static transient int e = " + e1.e);
		System.out.println("int f = " + e1.f);

	}
}
