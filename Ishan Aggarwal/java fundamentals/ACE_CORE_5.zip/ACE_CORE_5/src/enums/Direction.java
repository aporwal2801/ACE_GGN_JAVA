package enums;

public enum Direction {
	;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}

}
