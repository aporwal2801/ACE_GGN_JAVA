package cloning;

import java.util.ArrayList;
import java.util.List;

public class DemoClone {

	public static void main(String[] args) throws CloneNotSupportedException {
		// TODO Auto-generated method stub

		Employee e1 = new Employee(1, "Ishan");
		Employee e2 = e1.clone();
		System.out.println(e1 == e2);
		e1.setId(2);
		e1.setName("Aggarwal");
		System.out.println("e2----" + e2.getId());
		System.out.println("e2----" + e2.getName());

	}

}
