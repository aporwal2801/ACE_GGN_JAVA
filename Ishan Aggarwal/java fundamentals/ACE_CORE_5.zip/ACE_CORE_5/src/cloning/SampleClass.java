package cloning;

public class SampleClass {

}
