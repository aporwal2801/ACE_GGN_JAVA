package annotations;

public @interface Child {

}
