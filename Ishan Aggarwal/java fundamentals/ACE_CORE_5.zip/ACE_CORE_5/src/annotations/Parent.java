package annotations;

import java.lang.annotation.Inherited;

@Inherited
public @interface Parent {

}
