package use.casemail;

import java.util.ArrayList;
import java.util.List;

public class SequencePrinter {

	private int max_number = 10;
	private Object lock = new Object();
	List<Thread> threadList = new ArrayList<>();
	private int value_1 = 1;
	private int value_2 = 2;
	private int value_3 = 3;
	private int index = 0;
	Thread t = null;

	public SequencePrinter(int max_number) {
		this.max_number = max_number;
	}

	private void addThreads(int number_of_threads) {
		for (int i = 0; i < number_of_threads; i++) {
			switch (i % number_of_threads) {
			case 0:
				t = new Thread(printOneSequenceTask);
				break;
			case 1:
				t = new Thread(printTwoSequenceTask);
				break;
			case 2:
				t = new Thread(printThreeSequenceTask);
				break;
			}
			threadList.add(t);
		}
	}

	private void await() {
		for (Thread t : threadList) {
			try {
				t.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void startThreads() {
		for (Thread t : threadList) {
			t.start();
		}
	}

	private Thread getThread(int index) {
		return threadList.get(index % threadList.size());
	}

	private Runnable printOneSequenceTask = new Runnable() {
		@Override
		public void run() {
			while (value_1 <= max_number) {
				synchronized (lock) {
					while (value_1 <= max_number
							&& !Thread.currentThread().equals(getThread(index))) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					if (value_1 > max_number) {
						break;
					}
					System.out.println(Thread.currentThread().getName()
							+ " <--> " + value_1);
					value_1 += 3;
					index = index + 1;
					lock.notifyAll();
				}
			}
		}
	};

	Runnable printTwoSequenceTask = new Runnable() {
		@Override
		public void run() {
			while (value_2 <= max_number) {
				synchronized (lock) {
					while (value_2 <= max_number
							&& !Thread.currentThread().equals(getThread(index))) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					if (value_2 > max_number) {
						break;
					}
					System.out.println(Thread.currentThread().getName()
							+ " <--> " + value_2);
					value_2 += 3;
					index = index + 1;
					lock.notifyAll();
				}
			}
		}
	};

	Runnable printThreeSequenceTask = new Runnable() {
		@Override
		public void run() {
			while (value_3 <= max_number) {
				synchronized (lock) {
					while (value_3 <= max_number
							&& !Thread.currentThread().equals(getThread(index))) {
						try {
							lock.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					if (value_3 > max_number) {
						break;
					}
					System.out.println(Thread.currentThread().getName()
							+ " <--> " + value_3);
					value_3 += 3;
					index = index + 1;
					lock.notifyAll();
				}
			}
		}
	};

	public static void main(String[] args) {

		SequencePrinter sequencePrinter = new SequencePrinter(100);
		sequencePrinter.addThreads(3);
		sequencePrinter.startThreads();
		sequencePrinter.await();

	}
}
