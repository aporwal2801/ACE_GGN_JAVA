package use.casemail;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TablePrinter {

	private final int MAX = 10;
	private List<Thread> threadList = new ArrayList<>();
	private Thread thread = null;
	private static int numbers[] = null;
	private Object monitor = new Object();
	private int counter = 1;
	private int index = 0;
	private int temp = 0;

	private Runnable printTask = new Runnable() {
		@Override
		public void run() {
			while (counter <= 10) {
				Thread currentThread = Thread.currentThread();
				synchronized (monitor) {
					while (counter <= 10
							&& !currentThread.equals(getThread(index))) {
						try {
							monitor.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					if (counter > 10) {
						break;
					}

					temp = index % threadList.size();
					
					System.out.println("Thread : "
							+ Thread.currentThread().getName() + " <--> "
							+ numbers[temp] + " * "
							+ counter + " = "
							+ numbers[temp] * counter);

					if (currentThread.equals(
							getThread(threadList.size()-1))) {
						counter++;
					}

					index++;
					monitor.notifyAll();
				}
			}
		}
	};

	private void addThreads(int totalThreads, Runnable task) {
		for (int i = 0; i < totalThreads; i++) {
			thread = new Thread(task);
			threadList.add(thread);
		}
	}

	private void startThreads() {
		for (Thread thread : threadList) {
			thread.start();
		}
	}

	private void await() {
		for (Thread thread : threadList) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private Thread getThread(int index) {
		return threadList.get(index % threadList.size());
	}

	public static void main(String[] args) {

		TablePrinter tablePrinter = new TablePrinter();
		Scanner scanner = new Scanner(System.in);

		System.out.println("Main Thread Started!!!");
		System.out.println("Enter number of Threads --- ");
		int totalThreads = scanner.nextInt();
		numbers = new int[totalThreads];
		for (int i = 0; i < totalThreads; i++) {
			System.out
					.println("Enter " + i + " number for table printing --- ");
			numbers[i] = scanner.nextInt();
		}

		tablePrinter.addThreads(totalThreads, tablePrinter.printTask);
		tablePrinter.startThreads();
		tablePrinter.await();

		System.out.println("Main Thread Ended!!!");
	}
}
