package use.casemail;

import java.util.ArrayList;
import java.util.List;

public class AlternateThreadExecutor {

	private int max = 10;
	List<Thread> tList = new ArrayList<>();
	private int index = 0;
	private int value = 1;
	private Object lock = new Object();

	public AlternateThreadExecutor(int i) {
		this.max = i;
	}

	private Runnable task = new Runnable() {

		@Override
		public void run() {
			while (value <= max) {
				synchronized (lock) {
					try {
						while (value <= max
								&& !Thread.currentThread().equals(
										getThread(index))) {
							lock.wait();
						}
						if (value > max) {
							break;
						}
					} catch (Exception e) {
						e.printStackTrace();
					}

					System.out.println(Thread.currentThread().getName()
							+ " <-> " + getNextValue());

					index = index + 1;
					lock.notifyAll();
				}
			}
		}
	};

	private int getNextValue() {
		return value++;
	}

	private Thread getThread(int index) {
		return tList.get(index % tList.size());
	}

	private void await() {
		for (Thread thread : tList) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	private void start() {
		for (Thread thread : tList) {
			thread.start();
		}
	}

	private void addThreads(int numberOfThreads, Object task2) {
		for (int i = 0; i < numberOfThreads; i++) {
			Thread thread = new Thread(task);
			tList.add(thread);
		}
	}

	public static void main(String[] args) {

		System.out.println("Main Program started!!!");
		AlternateThreadExecutor alternateThreadExecutor = new AlternateThreadExecutor(
				100);
		alternateThreadExecutor.addThreads(6, alternateThreadExecutor.task);
		alternateThreadExecutor.start();
		alternateThreadExecutor.await();
		System.out.println("Main Program terminated!!!");

	}
}
