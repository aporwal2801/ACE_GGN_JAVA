package use.casemail;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class TestSharedList {

	private class Producer implements Runnable {

		List<Integer> myList = null;
		Random random = new Random();

		public Producer(List<Integer> list) {
			myList = list;
		}

		@Override
		public void run() {
			while (true) {
				synchronized (myList) {
					while (myList.size() == 10) {
						try {
							System.out.println("LIST IS FULL");
							myList.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					int number = random.nextInt(100);
					System.out.println("Produced : " + number);
					myList.add(number);
					myList.notifyAll();
				}
			}
		}
	}

	private class Consumer implements Runnable {

		List<Integer> myList = null;

		public Consumer(List<Integer> list) {
			myList = list;
		}

		@Override
		public void run() {
			while (true) {
				synchronized (myList) {
					while (myList.isEmpty()) {
						try {
							System.out.println("LIST IS EMPTY");
							myList.wait();
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
					try {
						Thread.sleep(1500);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					System.out.println("Consumed : "
							+ myList.get(myList.size() - 1));
					myList.remove(myList.size() - 1);
					myList.notifyAll();
				}
			}
		}
	}

	public static void main(String[] args) {

		List<Integer> list = new ArrayList<>(10);
		TestSharedList t = new TestSharedList();
		Producer producer = t.new Producer(list);
		Consumer consumer = t.new Consumer(list);
		Thread producerThread = new Thread(producer);
		Thread consumerThread = new Thread(consumer);
		producerThread.start();
		consumerThread.start();
	}

}
