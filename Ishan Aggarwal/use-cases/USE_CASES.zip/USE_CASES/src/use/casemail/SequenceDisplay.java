package use.casemail;

public class SequenceDisplay {

	static Object monitor = new Object();
	static final int MAX = 100;

	static boolean one = true;
	static boolean two = false;
	static boolean three = false;

	public static void main(String[] args) {

		Thread t1 = new Thread(new SequenceDisplayImpl(1));
		Thread t2 = new Thread(new SequenceDisplayImpl(2));
		Thread t3 = new Thread(new SequenceDisplayImpl(3));
		t1.start();
		t2.start();
		t3.start();

	}

	static class SequenceDisplayImpl implements Runnable {

		int threadId;
		int counter_1 = 1;
		int counter_2 = 2;
		int counter_3 = 3;

		SequenceDisplayImpl(int threadId) {
			this.threadId = threadId;
		}

		public void run() {
			print();
		}

		private void print() {
			try {
				while (counter_1 <= MAX && counter_2 <= MAX && counter_3 <= MAX) {
					Thread.sleep(100);
					synchronized (monitor) {
						if (1 == threadId) {
							printOneSequence();
						}
						if (2 == threadId) {
							printTwoSequence();
						}
						if (3 == threadId) {
							printThreeSequence();
						}
					}
				}
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}

		private void printThreeSequence() throws InterruptedException {
			if (!three) {
				monitor.wait();
			} else {
				System.out.println(Thread.currentThread().getName() + " <--> "
						+ counter_3);
				one = true;
				two = false;
				three = false;
				counter_3 += 3;
				monitor.notifyAll();
			}
		}

		private void printTwoSequence() throws InterruptedException {
			if (!two) {
				monitor.wait();
			} else {
				System.out.println(Thread.currentThread().getName() + " <--> "
						+ counter_2);
				one = false;
				two = false;
				three = true;
				counter_2 += 3;
				monitor.notifyAll();
			}
		}

		private void printOneSequence() throws InterruptedException {
			if (!one) {
				monitor.wait();
			} else {
				System.out.println(Thread.currentThread().getName() + " <--> "
						+ counter_1);
				one = false;
				two = true;
				three = false;
				counter_1 += 3;
				monitor.notifyAll();
			}
		}
	}
}