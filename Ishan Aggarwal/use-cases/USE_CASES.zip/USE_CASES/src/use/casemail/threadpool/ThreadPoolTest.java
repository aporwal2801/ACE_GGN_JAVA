package use.casemail.threadpool;

public class ThreadPoolTest {
	public static void main(String[] args) throws Exception {
		ThreadPool threadPool = new ThreadPool(4);
		Runnable task = new Task();
		threadPool.execute(task);
		threadPool.execute(task);

		threadPool.shutdown();

		threadPool.execute(task);
		threadPool.execute(task);
	}
}