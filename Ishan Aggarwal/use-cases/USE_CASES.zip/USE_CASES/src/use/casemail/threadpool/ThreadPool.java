package use.casemail.threadpool;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

class ThreadPool {

	private BlockingQueue<Runnable> taskQueue;
	private volatile boolean poolShutDownInitiated = false;
	private WorkerThread[] workerThreads;

	public WorkerThread[] getWorkerThreads() {
		return workerThreads;
	}

	public ThreadPool(int nThreads) {
		taskQueue = new LinkedBlockingQueue<Runnable>(nThreads);
		workerThreads = new WorkerThread[nThreads];

		// Create and start nThreads number of threads.
		for (int i = 1; i <= nThreads; i++) {
			WorkerThread workerThread = new WorkerThread(taskQueue, this);
			workerThreads[i-1] = workerThread;
			workerThread.setName("Thread-" + i);
			System.out.println("Thread-" + i + " created in ThreadPool.");
			workerThread.start(); // start thread
		}
	}

	public synchronized void execute(Runnable task) throws Exception {
		if (this.poolShutDownInitiated) {
			throw new Exception(
					"ThreadPool has been shutDown, no further tasks can be added");

		}
		System.out.println("task has been added.");
		this.taskQueue.put(task);
	}

	public boolean isPoolShutDownInitiated() {
		return poolShutDownInitiated;
	}

	public synchronized void shutdown() {
		this.poolShutDownInitiated = true;
		System.out.println("ThreadPool SHUTDOWN initiated.");
	}
}