package use.case7;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CustomConcurrentCounter {

	private int count = 0;
	List<Thread> threadList = new ArrayList<>();
	Thread thread = null;
	private static final int TOTAL_REPITIONS = 10000;

	public synchronized int increment() {
		count++;
		return count;
	}

	Runnable incrementTask = new Runnable() {
		@Override
		public void run() {
			for (int i = 0; i < TOTAL_REPITIONS; i++) {
				increment();
			}
		}
	};

	private void addThreads(int totalThreads, Runnable task) {
		for (int i = 0; i < totalThreads; i++) {
			thread = new Thread(task);
			threadList.add(thread);
		}
	}

	private void start() {
		for (Thread thread : threadList) {
			thread.start();
		}
	}

	private void await() {
		for (Thread thread : threadList) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("resource")
	public static void main(String[] args) {

		System.out.println("Main thread started!!!");
		Scanner scanner = new Scanner(System.in);
		System.out.println("Input number of threads");
		int numberOfThreads = scanner.nextInt();
		CustomConcurrentCounter customConcurrentCounter = new CustomConcurrentCounter();
		customConcurrentCounter.addThreads(numberOfThreads,
				customConcurrentCounter.incrementTask);
		customConcurrentCounter.start();
		customConcurrentCounter.await();

		System.out.println("Count : " + customConcurrentCounter.count);
		System.out.println("Main thread ended!!!");
	}
}
