package use.case5;

import java.util.ArrayList;
import java.util.List;

public class CustomCyclicBarrier {

	private int totalNumberOfThreads;
	private List<Thread> threadList = new ArrayList<>();
	private Thread tempThread = null;
	private int countDownLatch = 0;
	private int total = 0;
	private int index = 1;
	private static CustomCyclicBarrier cyclicBarrier = null;

	private Runnable myTask = new Runnable() {
		@Override
		public void run() {

			total = doWork();
			cyclicBarrier.await();
			if (total == threadList.size()
					&& Thread.currentThread().equals(
							threadList.get(threadList.size()))) {
				countDownLatch = 0;
				index++;
			}
			total = doWork();
//			cyclicBarrier.await();

		}
	};

	public CustomCyclicBarrier(int total, Runnable runnable) {
		this.totalNumberOfThreads = total;
	}

	private synchronized int doWork() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Thread : " + Thread.currentThread().getName()
				+ " has reached barrier-: " + index);
		countDownLatch++;
		return countDownLatch;
	}

	private void addThreads(int totalThreads, Runnable task) {
		for (int i = 0; i < totalThreads; i++) {
			tempThread = new Thread(task);
			threadList.add(tempThread);
		}
	}

	private void startThreads() {
		for (Thread thread : threadList) {
			thread.start();
		}
	}

	private void await() {
		for (Thread thread : threadList) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("Main Thread Started!!!");
		cyclicBarrier = new CustomCyclicBarrier(5, new Runnable() {
			@Override
			public void run() {
				System.out
						.println("All threads have arrived at the barrier, lets play!");
			}
		});
		cyclicBarrier.addThreads(cyclicBarrier.totalNumberOfThreads,
				cyclicBarrier.myTask);
		cyclicBarrier.startThreads();
		// cyclicBarrier.await();
		// System.out.println("Main Thread Ended!!!");
	}
}
