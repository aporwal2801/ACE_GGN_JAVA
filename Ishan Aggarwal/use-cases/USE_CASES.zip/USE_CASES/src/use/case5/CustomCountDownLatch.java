package use.case5;

import java.util.ArrayList;
import java.util.List;

public class CustomCountDownLatch {

	private int totalNumberOfThreads;
	private List<Thread> threadList = new ArrayList<>();
	private Thread tempThread = null;
	private int countDownLatch = 0;
	private int total = 0;

	private Runnable myTask = new Runnable() {
		@Override
		public void run() {

			total = doWork();
			if (total == threadList.size()) {
				System.out
						.println("All threads are UP and work is completed!!!");
			}
		}
	};

	public CustomCountDownLatch(int total) {
		this.totalNumberOfThreads = total;
	}

	private synchronized int doWork() {
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("Thread : " + Thread.currentThread().getName()
				+ " is UP");
		countDownLatch++;
		return countDownLatch;
	}

	private void addThreads(int totalThreads, Runnable task) {
		for (int i = 0; i < totalThreads; i++) {
			tempThread = new Thread(task);
			threadList.add(tempThread);
		}
	}

	private void startThreads() {
		for (Thread thread : threadList) {
			thread.start();
		}
	}

	private void await() {
		for (Thread thread : threadList) {
			try {
				thread.join();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		System.out.println("Main Thread Started!!!");
		CustomCountDownLatch countDownLatch = new CustomCountDownLatch(5);
		countDownLatch.addThreads(countDownLatch.totalNumberOfThreads,
				countDownLatch.myTask);
		countDownLatch.startThreads();
		countDownLatch.await();
		System.out.println("Main Thread Ended!!!");
	}
}
