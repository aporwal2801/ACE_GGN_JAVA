package use.case2;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MultiProducerConsumerBlockingQueueTest {

	public class CustomBlockingQueue<T> {

		public final int MAX = 5;
		public int size;
		List<T> list;

		public CustomBlockingQueue(int size) {
			this.size = size;
			list = new ArrayList<>(size);
		}

		public/* synchronized */void put(T element) throws InterruptedException {
			while (list.size() == MAX) {
				synchronized (list) {
					System.out.println("Queue is full. It contains " + MAX
							+ " elements!");
					list.wait();
				}
			}

			Thread.sleep(1000);
			synchronized (list) {
				list.add(element);
				System.out.println("Inserted element : " + element);
				list.notifyAll();
			}
		}

		public/* synchronized */T get() throws InterruptedException {
			while (list.size() == 0) {
				synchronized (list) {
					System.out
							.println("Queue is empty. It contains 0 elements!");
					list.wait();
				}
			}

			Thread.sleep(500);
			synchronized (list) {
				T removedElement = list.remove(list.size() - 1);
				list.notifyAll();
				return removedElement;
			}
		}

	}

	public static void main(String[] args) throws InterruptedException {

		MultiProducerConsumerBlockingQueueTest blockingQueueTest = new MultiProducerConsumerBlockingQueueTest();
		CustomBlockingQueue<Integer> blockingQueue = blockingQueueTest.new CustomBlockingQueue<Integer>(
				5);

		ExecutorService writerService = Executors.newFixedThreadPool(10);
		ExecutorService readerService = Executors.newFixedThreadPool(10);
		
		Thread writerThread = new Thread(new Runnable() {

			@Override
			public void run() {
				for (int i = 0; i < 1000; i++) {
					try {
						blockingQueue.put(i);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});

		Thread readerThread = new Thread(new Runnable() {
			@Override
			public void run() {
				while (true) {
					try {
						System.out.println("Removed element : "
								+ blockingQueue.get());
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		});

		for (int i = 0; i < 10; i++) {
			writerService.submit(writerThread);
		}
		for (int i = 0; i < 10; i++) {
			readerService.submit(readerThread);
		}
	}
}
