package com.sapient.garbage.collection;

public class StringPoolTest {

	public static void main(String[] args) {

		String str = new String("ABC");
		String str1 = "ABC";
		String intern = str.intern();
		
		
	}

}
