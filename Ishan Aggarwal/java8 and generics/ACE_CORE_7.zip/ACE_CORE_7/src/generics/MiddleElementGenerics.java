package generics;

// Note : 
// We define <T> in method syntax because we are not defining it as part of the class <T>
// If <T> is defined as part of the class name declaration than we can avoid it in the method definition.

public class MiddleElementGenerics {

	public <T> T getMiddleElement(T[] elements) {
		return elements[elements.length / 2];
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[] array = new Integer[] { 10, 5, 1, 2, 6 };
		Integer middle = new MiddleElementGenerics().getMiddleElement(array);
		System.out.println("Middle element: " + middle);

	}

}
