package generics;

public final class Algorithm {
	public static <T> T max(T x, T y) {
		// return x > y ? x : y;
		T element = null;
		return element;
	}

	public static <T extends Comparable<T>> int findFirstGreaterThan(T[] at,
			T elem) {
		return 0; // ...
	}
}
