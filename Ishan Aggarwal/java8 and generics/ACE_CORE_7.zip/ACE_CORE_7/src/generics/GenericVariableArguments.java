package generics;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class GenericVariableArguments {

	/**
	 * @param varAguments
	 *            - variable number of arguments
	 * @return list containing all the function arguments
	 */
	public static <T> List<T> getVariableArguments(T... varAguments) {
		List<T> list = new ArrayList<>();
		for (T element : varAguments) {
			list.add(element);
		}
		return list;
	}

	public static void main(String[] args) {
		@SuppressWarnings("unchecked")
		List<? extends Object> variableArguments = GenericVariableArguments
				.getVariableArguments("Ishan", 34, 45.00, "Aggarwal");

		List<Object> variableArguments1 = GenericVariableArguments
				.<Object> getVariableArguments("Ishan", 34, 45.00, "Aggarwal");
		System.out.println(variableArguments);

		List<? extends Object> variableArguments2 = GenericVariableArguments
				.getVariableArguments(new A(), new B());

		List<Object> variableArguments3 = GenericVariableArguments
				.<Object> getVariableArguments(new A(), new B());

		System.out.println(variableArguments2);

		GenericVariableArguments.test(1, "Hello");
		
	}

	public static <T> void test(T t1, T t2) {
		t1 = t2;
		System.out.println(t1);
	}

}

class A implements Serializable, Cloneable {

}

class B implements Serializable, Cloneable {

}