package generics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class GenericsExample {

	// private Object[] elements = new Object[10];

	public static void oldCopy(List dest, List src) {
		for (int i = 0; i < src.size(); i++) {
			dest.set(i, src.get(i));
		}
	}

	public static <T> void copyUsingGenerics(List<T> dest, List<? extends T> src) {
		for (int i = 0; i < src.size(); i++) {
			dest.set(i, src.get(i));
		}
	}

	public static <T> void copy(List<? super T> dest, List<? extends T> src) {
		for (int i = 0; i < src.size(); i++) {
			dest.set(i, src.get(i));
		}
	}

	public static <T> void method(T a, T b) {
		a = b;
		System.out.println("====" + a.toString());
		System.out.println("====" + b.toString());
	}

	public static void main(String[] args) {

		method("dfsdf", 45);

		Object[] objArray = new String[3];
//		List<Object> myList = new ArrayList<String>();
//		List<Number> numbers = new ArrayList<Integer>(); // Integer is a subtype
															// of Number

		List<?> myList22 = new ArrayList<>();

		 List<? extends Object> list = new ArrayList<>();
		// list.add("Ishan");
		// list.add(18);
		
		 List<? super Object> list1 = new ArrayList<>();
		 list1.add("Ishan");
		 list1.add(18);
		 list1.add(new Object());
		 
		 List<? super String> list2 = new ArrayList<>();
		 list1.add("Ishan");
		 list1.add(new String("Aggarwal"));

		List<Integer> ints = Arrays.asList(1, 2, 3, 4, 5, 6);
		List<String> strs = Arrays.asList("Ishan", "Aggarwal");
		List<Number> nums = Arrays.asList(1, 2, 4, 34.00);

		// copyUsingGenerics(strs, ints);
		copyUsingGenerics(nums, ints);

		copy(nums, ints);

		List<?> myRawList = new ArrayList<String>();
		// List<Object> myObjectList = new ArrayList<String>();

	}
}
