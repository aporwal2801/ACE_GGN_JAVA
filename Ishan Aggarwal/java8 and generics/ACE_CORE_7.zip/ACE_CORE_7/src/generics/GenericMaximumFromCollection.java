package generics;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class GenericMaximumFromCollection {

	public static <T extends Comparable<T>> T maximum(List<T> list) {
		list.sort(new Comparator<T>() {
			@Override
			public int compare(T o1, T o2) {
				return o1.compareTo(o2);
			}
		});
		return list.get(list.size() - 1);
	}

	public static void main(String[] args) {
		List<Integer> list = Arrays.asList(1, -2, 33, 84, 5, 17, 7);
		List<String> list1 = Arrays.asList("Ishan", "Aggarwal", "Varinder",
				"Sahota", "a");
		System.out.println(GenericMaximumFromCollection.maximum(list));
		System.out.println(GenericMaximumFromCollection.maximum(list1));
	}
}
