package generics;

public class GenericsExample1 {

	public static <T extends Comparable> T min(T[] a) {
		
		return null;
	}

	public static void main(String[] args) {

		
	}
}
