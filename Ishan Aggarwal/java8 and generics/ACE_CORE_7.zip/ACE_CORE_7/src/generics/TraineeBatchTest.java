package generics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * TraineeBatchTest
 * 
 */
public class TraineeBatchTest {

	/**
	 * TraineeBatch
	 * holding mapping information about batch and trainees of the
	 * batch
	 *
	 */
	private class TraineeBatch {

		public Map<Integer, List<String>> traineeBatchInformation = new HashMap<>();

		public void printInformation(Map<Integer, List<String>> batch) {
			Set<Integer> keySet = batch.keySet();
			for (Integer key : keySet) {
				System.out.println("Batch ID: " + key);
				System.out.println("Batch Trainees: " + batch.get(key));
			}
		}
	}

	public static void main(String[] args) {

		TraineeBatchTest traineeBatchTest = new TraineeBatchTest();
		TraineeBatch traineeBatch1 = traineeBatchTest.new TraineeBatch();
		TraineeBatch traineeBatch2 = traineeBatchTest.new TraineeBatch();

		// Trainees in batch 1
		List<String> lst = new ArrayList<>();
		lst.add("Ishan");
		lst.add("Gautam");

		// Trainees in batch 2
		List<String> lst1 = new ArrayList<>();
		lst1.add("Varinder");
		lst1.add("Rajat");

		// Adding elements to the map
		traineeBatch1.traineeBatchInformation.put(1, lst);
		traineeBatch2.traineeBatchInformation.put(2, lst1);

		// Printing Batch Information
		traineeBatch1.printInformation(traineeBatch1.traineeBatchInformation);
		traineeBatch2.printInformation(traineeBatch2.traineeBatchInformation);

	}
}
