package java8;

public @interface NotNull {

}
