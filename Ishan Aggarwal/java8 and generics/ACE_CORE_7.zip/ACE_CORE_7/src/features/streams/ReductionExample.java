package features.streams;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;


public class ReductionExample {

    public static void main(String... args) {
        
        List<Integer> list = Arrays.asList(2,4,7,8);
        List<Integer> list1 = Arrays.asList();
        
        Optional<Integer> red = 
        list.stream()
                .reduce(Integer::max);
        
        System.out.println("red = " + red);
        
               
        Optional<Integer> red1 = 
                list1.stream()
                        .reduce(Integer::max);
                
                System.out.println("red1 = " + red1);
                
       Integer red2 = 
                        list.stream()
                                .reduce(0,Integer::max);
                        
                        System.out.println("red2 = " + red2);                
        
      Integer red3 = 
                                list1.stream()
                                        .reduce(0,Integer::max);
                                
                                System.out.println("red3 = " + red3);
    }
}
