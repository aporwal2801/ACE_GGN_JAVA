package features;

import java.util.Arrays;
import java.util.List;

public class Example1 {
	public static void main(String[] args) {
		List<Integer> list1 = Arrays.asList(1, 2, 3);
		List<Integer> list2 = Arrays.asList(1, 2);
		// list1.size();
		List<List<Integer>> list = Arrays.asList(list1, list2);
		list.stream().map(l -> l.size()).forEach(System.out::println);
	}

}
