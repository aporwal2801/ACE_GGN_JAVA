package features;

import java.util.Arrays;
import java.util.List;

public class Example1 {
	public static void main(String[] args) {
		List<Integer> list1 = Arrays.asList(1,2,3);
		//list1.size();
		List<List<Integer>> list = Arrays.asList(list1);
		list.stream()
			.map(l -> l.size())
			.forEach(System.out::println);
	}

}
