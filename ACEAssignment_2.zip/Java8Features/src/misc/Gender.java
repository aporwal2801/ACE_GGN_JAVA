package misc;

public enum Gender { MALE, FEMALE }