package misc;

public class InterfaceExample implements FuncInt1, FuncInt2 {

	@Override
	public void show() {
	}
	
	@Override
	public void method1(String str) {
	}

	
	//comment below and check
	@Override
	public void print(String str){
		System.out.println("MyClass logging::"+str);
		FuncInt1.print1("abc");
	}
	
}

@FunctionalInterface
interface FuncInt1 {

	void method1(String str);
	
	default void print(String str){
		System.out.println("FuncInt1 print::"+str);
	}
	
	static void print1(String str){
		System.out.println("Printing1 "+str);
	}
	
	//uncomment below and check
	/*default String toString(){
		return "i1";
	}*/
	
}

@FunctionalInterface
 interface FuncInt2 {

	//static void  show();
	//void show1();
	void  show();
	
	
	default void print(String str){
		System.out.println("FuncInt2 print::"+str);
	}

}