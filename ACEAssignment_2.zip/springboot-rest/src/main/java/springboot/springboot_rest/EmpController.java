package springboot.springboot_rest;

import java.text.ParseException;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmpController {

	EmployeeService empService = new EmployeeService();

	@RequestMapping(value = "/emps", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<Employee> getAllEmp() {
		List<Employee> emps = empService.getAllEmp();
		return emps;

	}

	@RequestMapping(value = "/emps/{empid}/{empDep}", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<Employee> updateEmp(@PathVariable int empid,
			@PathVariable String empDep) throws ParseException {
		empService.changeEmpDepartment(empid, empDep);
		return empService.getAllEmp();

	}

	@RequestMapping(value = "/emps/insert/{empid}/{empName}/{empDep}", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<Employee> addEmp(@PathVariable int empid,
			@PathVariable String empName, @PathVariable String empDep)
			throws ParseException {
		Employee emp = new Employee();
		emp.setId(empid);
		emp.setName(empName);
		emp.setDepartment(empDep);
		empService.addEmployee(emp);
		return empService.getAllEmp();

	}
	@RequestMapping(value = "/emps/competency", method = RequestMethod.GET, headers = "Accept=application/json")
	public String getCompetency() {
		String competency = empService.getCompetency();
		return competency;

	}
}