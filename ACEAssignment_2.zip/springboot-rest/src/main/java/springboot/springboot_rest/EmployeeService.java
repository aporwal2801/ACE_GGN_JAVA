package springboot.springboot_rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.client.RestTemplate;

public class EmployeeService {
	static final List<Employee> emplist=new ArrayList<>();
	public List<Employee> getAllEmp() {
		return emplist;
	}

	public void addEmployee(Employee emp) {
		emplist.add(emp);
	}

	public void changeEmpDepartment(int empid, String empDep) {
		for (Employee employee : emplist) {
			if(employee.getId()==empid){
				employee.setDepartment(empDep);
			}
		}
	}
	
	public String getCompetency() {
		final String uri = "http://localhost:8082/comp/";
	    RestTemplate restTemplate = new RestTemplate();
	    String result = restTemplate.getForObject(uri, String.class);
	    System.out.println(result);
	    return result;
	}

}
