package myspring.jpa;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="Equity")
public class Equity {
	private String symbol;
	private String securityName;
	private String type;
	private int qty;
	@Id
    @GeneratedValue
	public String getSymbol() {
		return symbol;
	}
	public Equity(){}
	public Equity(String symbol, String securityName, String type, int qty) {
		super();
		this.symbol = symbol;
		this.securityName = securityName;
		this.type = type;
		this.qty = qty;
	}
	public void setSymbol(String symbol) {
		this.symbol = symbol;
	}
	@Column(name = "SecurityName")
	public String getSecurityName() {
		return securityName;
	}
	public void setSecurityName(String securityName) {
		this.securityName = securityName;
	}
	@Column(name = "Type")
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Column(name = "Qty")
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
}
