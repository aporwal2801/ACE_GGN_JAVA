package myspring.jpa;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("EquityDao")
@Transactional
public class EquityDAOImpl implements EqityDAO {

	@PersistenceContext
	private EntityManager manager;
	
	public void setEntityManager(EntityManager entityManager){
		this.manager=entityManager;
	}

	@Transactional
	public List<Equity> getAllEquity() {
		List<Equity> equity = manager.createQuery("Select a From Equity a",
				Equity.class).getResultList();
		return equity;
	}

	@Transactional
	public void addEqity(Equity equity) {
		// equity.setSecurityName("securty1");
		manager.persist(equity);
	}

}
