package myspring.jpa;

import java.util.List;

public interface EqityDAO {

		public List<Equity> getAllEquity();
		public void addEqity(Equity equity);
	}
	

