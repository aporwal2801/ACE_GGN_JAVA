package myspring.jpa;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"spring.xml");
		EqityDAO dao=(EqityDAO)context.getBean("EquityDao");
		dao.addEqity(new Equity("$", "Eqity1", "Buy", 2));

		
		
	}
}
