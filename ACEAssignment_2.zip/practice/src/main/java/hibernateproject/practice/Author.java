package hibernateproject.practice;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name="Author")  
@Entity  
public class Author {
	private int id;
	private String workCategory;
	private String firstName;
	private String lastName;
	private String nationality;
	private Date dob;
	@Embedded
	private Address address;
	public Author(){}
	public Author(int id, String workCategory, String firstName,
			String lastName, String nationality, Date dob) {
		super();
		this.id = id;
		this.workCategory = workCategory;
		this.firstName = firstName;
		this.lastName = lastName;
		this.nationality = nationality;
		this.dob = dob;
	}
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	 @Column(name="Work_Category")
	public String getWorkCategory() {
		return workCategory;
	}
	public void setWorkCategory(String workCategory) {
		this.workCategory = workCategory;
	}
	@Column(name="F_Name")
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	@Column(name="L_Name")
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Column(name="Nationality")
	public String getNationality() {
		return nationality;
	}
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}
	@Column(name="DoB")
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	@Column(name="Address")
	public Address getAddress() {
		return address;
	}
	
	public void setAddress(Address address) {
		this.address = address;
	}
	
	

}
