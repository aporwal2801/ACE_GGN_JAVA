package hibernateproject.practice;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class BookStoreApp {
	private static SessionFactory factory; 
	public static void main(String[] args) {
		try{
	         factory = new Configuration().configure().buildSessionFactory();
	      }catch (Throwable ex) { 
	         System.err.println("Failed to create sessionFactory object." + ex);
	         throw new ExceptionInInitializerError(ex); 
	      }
		
		 Session session = factory.openSession();
		/* Book book=new Book(111, "Hibernate", Date.valueOf(str));
		 session.save(book);
		 Author au = (Author)session.load(Author.class, new Integer(2));
		Author author=new Author(7, "Engg", "shashi", "sahu", "Indian", Date.valueOf(str));
		 System.out.println(au.getId());
		 au.setLastName("kumar");
		 Address a=new Address();
		 a.setLocality("MBD");
		 au.setAddress(a);
		*/ 
	/*	 Book book=new Book(112, "Hibernate", Date.valueOf(str));
		 BookCategories category=new BookCategories();
		 category.setCategoryId(111);
		 category.setCategoryName("Hibernate");
		 //Set<BookCategories> bookCategoryset=new HashSet();
		 Set<BookCategories> bookCategoryset= book.getBookscategory();
		// bookCategoryset.add(category);
		 book.setBookscategory(bookCategoryset);
		 session.persist(category);
		 tx.commit();
	*/	 
	}

}
