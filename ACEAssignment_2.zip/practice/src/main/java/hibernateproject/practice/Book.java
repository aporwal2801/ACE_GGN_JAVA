package hibernateproject.practice;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="Books_Tab")
public class Book {
	private int bookId;
	private String bookTitle;
	private Date publicationDate;
	
	public Book(){}
	
	@ManyToMany(
			mappedBy="books",
			cascade={CascadeType.PERSIST})
	public Set<BookCategories> bookscategory=new HashSet<BookCategories>();
	
	@Id
	@Column(name = "bookId")
	public int getBookId() {
		return bookId;
	}


	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public Set<BookCategories> getBookscategory() {
		return bookscategory;
	}

	public void setBookscategory(Set<BookCategories> bookscategory) {
		this.bookscategory = bookscategory;
	}


	public Book(int bookId, String bookTitle, Date publicationDate) {
		super();
		bookId = bookId;
		this.bookTitle = bookTitle;
		this.publicationDate = publicationDate;
	}


	@Column(name="Book_Title")
	public String getBookTitle() {
		return bookTitle;
	}

	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	@Column(name="publication_date")
	public Date getPublicationDate() {
		return publicationDate;
	}

	public void setPublicationDate(Date publicationDate) {
		this.publicationDate = publicationDate;
	}
	
	

}
