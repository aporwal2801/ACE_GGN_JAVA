package day3;

public class B extends A{
	public void m1(Integer i){
		System.out.println("B");
	}
	public static void main(String[] args) {
		A a=new B();
		a.m1(new Integer(1));
	}
}
