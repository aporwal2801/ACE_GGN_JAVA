package day3;

public class A {
	public void m1(int i){
		System.out.println("A");
	}

}
