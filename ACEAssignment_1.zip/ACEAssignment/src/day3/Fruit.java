package day3;

public class Fruit {
	String name;
	String Flavar;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFlavar() {
		return Flavar;
	}

	public void setFlavar(String flavar) {
		Flavar = flavar;
	}
	
	@Override
	public int hashCode() {
		return name.hashCode();
	}
	
	@Override
	public boolean equals(Object o) {
		Fruit f=(Fruit)o;
		if(f.name.equals(this.name))
			return true;
		return false;
	}

}
