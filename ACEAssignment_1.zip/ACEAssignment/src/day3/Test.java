package day3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		List<Fruit> list = new ArrayList();
		Map m=new HashMap();
		Scanner s=new Scanner(System.in);
		int i=0;
		while(s.hasNext()){
			Fruit f=new Fruit();
			f.setName(s.next());
			list.add(f);
			i++;
			if(i>=5)
				break;
		}
		for (Fruit fruit : list) {
			System.out.print(fruit.name);
		}
		Collections.sort(list,new Comparator() {

			@Override
			public int compare(Object o1, Object o2) {
				Fruit f1=(Fruit)o1;
				Fruit f2=(Fruit)o2;
				return f1.name.compareTo(f2.name);
			}
		});
		for (Fruit fruit : list) {
			System.out.print(fruit.name);
		}
		System.out.println("Is it contain mango "+list.contains("Mango"));
	}

}
