package MyCountDownLatch;

public class MyCountDown {
	volatile int count;

	public MyCountDown(int count) {
		super();
		this.count = count;
	}
	
	public synchronized void countDown() {
		if(this.count>0)
			this.count=count-1;
	}
	

}
