import java.io.Serializable;

public class Employee implements Serializable  {
	String name;
	static int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static int getAge() {
		return age;
	}

	public static void setAge(int age) {
		Employee.age = age;
	}
}
