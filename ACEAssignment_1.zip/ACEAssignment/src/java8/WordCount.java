package java8;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Stream;

public class WordCount {
	public static void main(String[] args) throws IOException {
		Path path = Paths.get("D:/TradesRealTimeFile.txt");
        Stream<String> lines = Files.lines(path)
           .flatMap(line -> Arrays.stream(line.split("#")));
           
        
        
    }

}


