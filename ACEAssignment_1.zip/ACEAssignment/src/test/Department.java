package test;

import java.io.Serializable;

public class Department implements Serializable {
	String name;
	int id;
	public Department(String name, int id) {
		super();
		this.name = name;
		this.id = id;
	}
	
}
