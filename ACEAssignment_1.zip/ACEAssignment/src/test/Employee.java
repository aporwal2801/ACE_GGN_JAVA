package test;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Employee implements Cloneable, Serializable {
	String name;
	int age;
	Department d;

	public Employee(String name, int age, Department d) {
		super();
		this.name = name;
		this.age = age;
		this.d = d;
	}

	public static Object deepClone(Object object) {
		try {
			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ObjectOutputStream oos = new ObjectOutputStream(baos);
			oos.writeObject(object);
			ByteArrayInputStream bais = new ByteArrayInputStream(
					baos.toByteArray());
			ObjectInputStream ois = new ObjectInputStream(bais);
			return ois.readObject();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static void main(String[] args) throws IOException {
		Employee e= new Employee("Shashi", 25, new Department("MyDept", 123));
		Employee e2 =(Employee)deepClone(e);
		System.out.println(e2.name);
		System.out.println(e2.age);
		System.out.println(e2.d.id);
		System.out.println(e2.d.name);

	}
}
