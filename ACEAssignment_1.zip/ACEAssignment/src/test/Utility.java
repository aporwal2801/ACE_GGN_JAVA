package test;

public class Utility {
	
	public static void deepclone(Object obj){
		obj.getClass().getDeclaredMethods();
	}

}
