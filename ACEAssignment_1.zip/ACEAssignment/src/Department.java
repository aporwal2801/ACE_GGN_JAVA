
public class Department {
	String name;
	

}
