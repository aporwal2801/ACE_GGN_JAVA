package pubsubwithwaitnotify;

import sequence.A;

public class B extends A {
	 int a(int a) throws Exception{
	return 1;
}
}
