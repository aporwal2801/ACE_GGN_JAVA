import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
public class SerializeDemo {
	
	
   public static void main(String [] args) {
	 Employee e = new Employee();
      e.name = "Shashi Sahu";
      
      try {
         FileOutputStream fileOut =
         new FileOutputStream("D:/employee.ser");
         ObjectOutputStream out = new ObjectOutputStream(fileOut);
         out.writeObject(e);
         out.close();
         fileOut.close();
         System.out.printf("Serialized data is saved in D:/employee.ser");
         e.age=15;
         System.out.println(e.age);
      }catch(IOException i) {
         i.printStackTrace();
      }
   }
}