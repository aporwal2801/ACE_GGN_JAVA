package sequence;

import java.io.IOException;

public class A {
	public float a(float a) throws IOException{
		return a;
		
	}

}
