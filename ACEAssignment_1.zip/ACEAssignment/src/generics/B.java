package generics;

import java.io.Serializable;

public class B implements Serializable,Cloneable {

}
