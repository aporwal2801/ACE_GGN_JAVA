package generics;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class GenericsExample {
	
	public static void main(String[] args) {
		HashMap<Integer,List<String>> map=new HashMap();
		List<String> names= new ArrayList();
		names.add("Shashi");
		names.add("sahu");
		map.put(1, names);
		map.put(2, names);
		
		System.out.println(map);
	}

}
