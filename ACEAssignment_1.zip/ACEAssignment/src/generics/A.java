package generics;

import java.io.Serializable;

public class A implements Serializable,Cloneable {

}
