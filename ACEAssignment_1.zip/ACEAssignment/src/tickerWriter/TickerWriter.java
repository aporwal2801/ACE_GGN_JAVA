package tickerWriter;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.stream.Stream;

public class TickerWriter {
    private static final String fileName = "D://fx.csv";
    private static final int MAX_LINES = 4400000;
    private static String header = "Date(with timestamp),Ticker,Currency From,Currency To,Exchange Rate";
    private static List<String> stickerList = new ArrayList<>();

    static{
        stickerList.add("INR/USD");
        stickerList.add("INR/EUR");
        stickerList.add("INR/GBP");
    }

    public static void main(String[] args) throws IOException{
          writeLargeFile();
          try(Stream<String> lines = Files.lines(Paths.get(fileName))){
              //lines.distinct().forEach(System.out::print);

          }
    }

    public static void writeLargeFile() throws FileNotFoundException, IOException {

        FileChannel rwChannel = new RandomAccessFile(fileName, "rw").getChannel();
        ByteBuffer wrBuf = rwChannel.map(FileChannel.MapMode.READ_WRITE, 0, 55*MAX_LINES);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        Random random=new Random();
        for(int i=0; i < MAX_LINES;i++){
            String timeStamp = new Date().toString();
            String sticker = stickerList.get(random.nextInt());
            String[] stickerArr = sticker.split("/");
            String line = timeStamp + ", " + sticker + ", "+ stickerArr[0] + ", "+stickerArr[1] + ", " + df.format(random.nextFloat())+"\n";
            wrBuf.put(line.getBytes());
            //rwChannel.write(wrBuf);
        }
        wrBuf.clear();
        rwChannel.close();
    }
}
