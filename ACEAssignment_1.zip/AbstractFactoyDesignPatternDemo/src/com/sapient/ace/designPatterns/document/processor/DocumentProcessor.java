package com.sapient.ace.designPatterns.document.processor;

import java.io.File;
import java.util.List;

import com.sapient.ace.designPatterns.data.Record;
import com.sapient.ace.designPatterns.document.parser.Parser;

public abstract class DocumentProcessor {
	
	public abstract Parser getParser();
	
	public void processDocument(String docName){
		File file = openDocument(docName);
		Parser parser = getParser();
		List<Record> records = parser.parse(file);
		processRecords(records);
		writeSummary();
		closeDocument();
	}

	private File openDocument(String docName) {
		System.out.println("Opening Document-->"+ docName);	
		return null;
	}
	
	private void processRecords(List<Record> records) {
		System.out.println("Records Processing Completed.");
	}

	private void writeSummary() {
		System.out.println("Writing Summary.....");
		
	}

	private void closeDocument() {
		System.out.println("Document Closed");		
	}

}
