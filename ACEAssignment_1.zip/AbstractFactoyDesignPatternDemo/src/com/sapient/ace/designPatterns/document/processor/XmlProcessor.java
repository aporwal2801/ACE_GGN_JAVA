package com.sapient.ace.designPatterns.document.processor;

import com.sapient.ace.designPatterns.document.parser.Parser;
import com.sapient.ace.designPatterns.document.parser.XmlParser;

public class XmlProcessor extends DocumentProcessor{

	@Override
	public Parser getParser() {		
		return new XmlParser();
	}

}
