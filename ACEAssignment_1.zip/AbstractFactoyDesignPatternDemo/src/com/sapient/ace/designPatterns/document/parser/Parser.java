package com.sapient.ace.designPatterns.document.parser;

import java.io.File;
import java.util.List;

import com.sapient.ace.designPatterns.data.Record;

public interface Parser {
	
	public List<Record> parse(File file);

}
