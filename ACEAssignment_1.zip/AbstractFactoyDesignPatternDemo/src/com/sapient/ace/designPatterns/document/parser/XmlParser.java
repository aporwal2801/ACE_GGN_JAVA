package com.sapient.ace.designPatterns.document.parser;

import java.io.File;
import java.util.List;

import com.sapient.ace.designPatterns.data.Record;

public class XmlParser implements Parser{

	@Override
	public List<Record> parse(File file) {
		System.out.println("\"XML\" content is parsed.");
		return null;
	}
}
