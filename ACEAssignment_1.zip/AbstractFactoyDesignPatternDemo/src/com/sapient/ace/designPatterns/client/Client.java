package com.sapient.ace.designPatterns.client;

import java.util.Scanner;

import com.sapient.ace.designPatterns.document.processor.DocumentProcessor;
import com.sapient.ace.designPatterns.factory.DocumentProcessorFactory;
import com.sapient.ace.designPatterns.factory.ProcessorFactory;
import com.sapient.ace.designPatterns.factory.ProcessorFactoryProducer;
import com.sapient.ace.designPatterns.media.processor.MediaProcessor;

public class Client {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String contentType = "";
		String fileName = "";
		String fileType = "";
		int i = 0;
		System.out.println("1. Enter Content Type document/media");
		System.out.println("2. Enter File Name ");
		System.out.println("3. Enter file Type Eg TEXT/XML/AUDIO/VIDEO");
		while (scan.hasNext()) {
			if (i == 0) {
				contentType = scan.next();
				i++;
			} else if (i == 1) {
				fileName = scan.next();
				i++;
			} else if (i == 2) {
				fileType = scan.next();
				break;
			}

		}
		ProcessorFactory processor = ProcessorFactoryProducer
				.getProcessorFactory(contentType);
		try {
			if (contentType.equalsIgnoreCase("document")) {
				DocumentProcessor docProcessor = processor
						.getDocumentProcessor(fileType);
				docProcessor.processDocument(fileName);
			} else if (contentType.equalsIgnoreCase("media")) {
				MediaProcessor mediaProcessor = processor
						.getMediaProcessor(fileType);
				mediaProcessor.processMedia(fileName);
			} else
				System.out
						.println("Please enter correct choice.Entered type not supported");
		} catch (NullPointerException e) {
			System.out
					.println("Please enter correct choice.Entered type not supported");
		}

	}
}
