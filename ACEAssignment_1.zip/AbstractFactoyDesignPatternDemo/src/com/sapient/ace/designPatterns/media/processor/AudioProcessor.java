package com.sapient.ace.designPatterns.media.processor;

import com.sapient.ace.designPatterns.document.parser.Parser;
import com.sapient.ace.designPatterns.media.parser.AudioParser;

public class AudioProcessor extends MediaProcessor{

	@Override
	public Parser getParser() {		
		return new AudioParser();
	}

}
