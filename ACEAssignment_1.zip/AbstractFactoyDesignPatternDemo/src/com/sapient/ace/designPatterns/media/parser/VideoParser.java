package com.sapient.ace.designPatterns.media.parser;

import java.io.File;
import java.util.List;

import com.sapient.ace.designPatterns.data.Record;
import com.sapient.ace.designPatterns.document.parser.Parser;

public class VideoParser implements Parser{

	@Override
	public List<Record> parse(File file) {
		System.out.println("\"Video\" content is parsed.");
		return null;
	}
}
