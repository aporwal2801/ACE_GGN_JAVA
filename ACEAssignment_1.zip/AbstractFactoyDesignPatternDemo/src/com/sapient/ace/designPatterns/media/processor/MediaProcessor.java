package com.sapient.ace.designPatterns.media.processor;

import java.io.File;
import java.util.List;

import com.sapient.ace.designPatterns.data.Record;
import com.sapient.ace.designPatterns.document.parser.Parser;

public abstract class MediaProcessor {
	
	public abstract Parser getParser();
	
	public void processMedia(String docName){
		File file = openFile(docName);
		Parser parser = getParser();
		List<Record> records = parser.parse(file);
		processRecords(records);
		writeSummary();
		closeFile();
	}

	private File openFile(String docName) {
		System.out.println("Opening Media file-->"+ docName);	
		return null;
	}
	
	private void processRecords(List<Record> records) {
		System.out.println("Media Processing Completed.");
	}

	private void writeSummary() {
		System.out.println("Writing Summary.....");
		
	}

	private void closeFile() {
		System.out.println("Media File Closed");		
	}

}
