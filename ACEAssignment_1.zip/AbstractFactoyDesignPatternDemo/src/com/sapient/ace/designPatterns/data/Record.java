package com.sapient.ace.designPatterns.data;

public class Record {

}
