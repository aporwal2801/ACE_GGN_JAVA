package com.sapient.ace.designPatterns.factory;

import com.sapient.ace.designPatterns.document.processor.DocumentProcessor;
import com.sapient.ace.designPatterns.media.processor.AudioProcessor;
import com.sapient.ace.designPatterns.media.processor.MediaProcessor;
import com.sapient.ace.designPatterns.media.processor.VideoProcessor;

public class MediaProcessorFactory implements ProcessorFactory{
	
	public  MediaProcessor getMediaProcessor(String fileType){
		if(fileType.equalsIgnoreCase("audio")){
			return new AudioProcessor();
		}
		else if (fileType.equalsIgnoreCase("video")) {
			return new VideoProcessor();
		}		
		return null;		
	}

	@Override
	public DocumentProcessor getDocumentProcessor(String type) {
		return null;
	}

}
