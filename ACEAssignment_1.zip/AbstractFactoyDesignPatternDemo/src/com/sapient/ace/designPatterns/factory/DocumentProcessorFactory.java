package com.sapient.ace.designPatterns.factory;

import com.sapient.ace.designPatterns.document.processor.DocumentProcessor;
import com.sapient.ace.designPatterns.document.processor.TextProcessor;
import com.sapient.ace.designPatterns.document.processor.XmlProcessor;
import com.sapient.ace.designPatterns.media.processor.MediaProcessor;

public class DocumentProcessorFactory implements ProcessorFactory {
	
	public DocumentProcessor getDocumentProcessor(String fileType){
		if(fileType.equalsIgnoreCase("Text")){
			return new TextProcessor();
		}
		else if (fileType.equalsIgnoreCase("XML")) {
			return new XmlProcessor();
		}		
		return null;		
	}

	@Override
	public MediaProcessor getMediaProcessor(String type) {
		return null;
	}

}
