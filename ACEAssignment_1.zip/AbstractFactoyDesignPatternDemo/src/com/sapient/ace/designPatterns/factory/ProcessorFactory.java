package com.sapient.ace.designPatterns.factory;

import com.sapient.ace.designPatterns.document.processor.DocumentProcessor;
import com.sapient.ace.designPatterns.media.processor.MediaProcessor;

public interface ProcessorFactory {
	MediaProcessor getMediaProcessor(String type);
	DocumentProcessor getDocumentProcessor(String type);
}
