package com.sapient.ace.designPatterns.factory;
public class ProcessorFactoryProducer {
	   public static ProcessorFactory getProcessorFactory(String choice){
	   
	      if(choice.equalsIgnoreCase("document")){
	         return new DocumentProcessorFactory();
	         
	      }else if(choice.equalsIgnoreCase("media")){
	         return new MediaProcessorFactory();
	      }
	      
	      return null;
	   }
	}