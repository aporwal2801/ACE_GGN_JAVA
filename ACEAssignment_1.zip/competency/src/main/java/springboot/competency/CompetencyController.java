package springboot.competency;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CompetencyController {

	final static List<String> comp = new ArrayList();

	@RequestMapping(value = "/comp", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<String> getAllEmp() {
		return comp;

	}

	@RequestMapping(value = "/comp/insert/{comptName}/", method = RequestMethod.POST, headers = "Accept=application/json")
	public List<String> addComp(@PathVariable String comptName) {
		comp.add(comptName);
		return comp;

	}
}