package com.sap;

import org.springframework.beans.factory.annotation.Autowired;

public class Address {
	@Autowired
	private Name name;

	public Name getName() {
		return name;
	}
/*
	public void setName(Name name) {
		this.name = name;
	}*/
	

		

}
