package com.sap;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"Spring-Module.xml");

		HelloWorld a = (HelloWorld) context.getBean("myBean");
		HelloWorld b = (HelloWorld) context.getBean("myBean");
		System.out.println(a==b);
		List<String> frnds=a.getFriends();
		for (String name : frnds) {
			System.out.println(name);
		}
		
	}
}