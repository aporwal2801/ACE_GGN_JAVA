package com.sap;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class A implements ApplicationContextAware{
	B b;

	
	@Override
	public void setApplicationContext(ApplicationContext arg0)
			throws BeansException {
		b=(B)arg0.getBean("b");
	}
	

}
